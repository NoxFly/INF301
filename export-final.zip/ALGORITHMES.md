# Introduction
Voici les différents algorithmes qui ont été implémenté afin de compléter l'APP1. Des fonctions imporantes pour les différents algorithmes ont aussi été incluse pour plus de claretée.

Note : Tout les algorithmes ci dessous ont été réalisé sous LateX

# Cesar
<img src="Algo_repos/cesar.JPG" width = 500>

## Algorithmes complémentaires
<img src="Algo_repos/double_algo2.JPG" width = 500>

# cryptSeq
<img src="Algo_repos/cryptSeq.JPG" width = 500>

## Algorithmes complémentaires
<img src="Algo_repos/double_algo.JPG" width = 500>


# decryptSeq (avec cryptSeq ?)
<img src="Algo_repos/decryptSeq.JPG" width = 500>


# Northwoods
<img src="Algo_repos/NorthWoods.JPG" width = 500>
